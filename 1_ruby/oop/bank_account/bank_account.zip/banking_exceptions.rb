class Withdraw_Exception < RuntimeError

end
